
<?php
include "db.php";
include "header.php";
include "admin_sidebar.php"; 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Student Registration Approval</title>
</head>
<body>



<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
    <div class="container-fluid"></div>
    <div class="container-fluid"></div>
      <div class="row" ></div>
      <div class="row" >
                    <div class="col-xl-4 col-lg-4 col-md-12 col-12" style="padding-top: 60px;padding-left: 60px;">
                    <div class="card" style="padding-top: 30px;">
            <h6 class="card-header" style="padding-top: 10px;">     <h3><center>Registration Approval</center></h3>
</h6>
            <div class="card-body">


            <form action="admin_student_register_approval_submit.php" method="post">
            <div class="form-group">

        <label for="studentId">Select Student ID:</label><br>
        <select id="classes" class="form-control form-control-lg" name="StudentID" required>
            <option value="">Select a Student</option>
            <?php

            include 'db.php';
            // Query to retrieve data from the database
            $query = "SELECT * FROM students";

            // Execute the query
            $result = $conn->query($query);

            // Check if the query was successful
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row["StudentID"] . "'>" . $row["StudentID"] . "</option>";
                }
            } else {
                echo "<option value=''>No Student found</option>";
            }

            // Close connection
            $conn->close();
            ?>
        </select>
        </div>
        <div class="form-group">
        <label for="registrationNumber">Registration Number:</label><br>
        <input type="text" class="form-control form-control-lg" id="registrationNumber" name="RegistrationNumber" required><br>
        <!-- Other fields for admin approval -->
        </div>
        <button type="submit" name="submit"class="btn btn-primary btn-lg btn-block">Approve Registration</button>
    </form>
    
                </div>
                </div>
            </div>
            </div>
            </div>
            </section>
                <?php include("footer.php"); ?>
            </div>
