<?php

// Include your database connection file
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Retrieve form data
    $StudentID = $_POST['StudentID'];
    $registrationNumber = $_POST['RegistrationNumber'];

    // Update the student's registration details using mysqli_query
    $query = "UPDATE students SET RegistrationNumber = '$registrationNumber' WHERE StudentID = $StudentID";
    $result = mysqli_query($conn, $query);

    // Check if update was successful
    if ($result) {
      //  echo "Student registration approved successfully.";
        header("Location: admin_student_register_approval.php"); // Redirect to the student dashboard or home page

    } else {
        echo "Error approving student registration: " . mysqli_error($mysqli);
    }
}

// Close connection

?>
