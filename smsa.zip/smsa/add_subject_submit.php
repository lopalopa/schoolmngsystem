<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Personal Information
    $sub_name = $_POST["sub_name"];
    $class_name = $_POST["class_name"];
    

    // Insert data into the database
    $sql = "INSERT INTO subject (class_name,sub_name)
            VALUES ('$class_name','$sub_name')";

    if ($conn->query($sql) === TRUE) {
        echo "Subject  information submitted successfully!";
        header("Location: add_subject.php"); // Redirect to the student dashboard or home page

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

?>
