<?php
include 'db.php';
// Process student login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $userType = $_POST["userType"]; // Retrieve the user type from the hidden input field

    // Validate student credentials
    $sql = "SELECT * FROM admin WHERE Username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row["PasswordHash"];

        // Verify the entered password against the stored hashed password
        if (password_verify($password, $hashedPassword)) {
            // Authentication successful
            session_start();
            $_SESSION["username"] = $username;
            $_SESSION["userType"] = $userType;
            header("Location: admin_dashboard.php"); // Redirect to the student dashboard or home page
            exit();
        } else {
            // Invalid password
            header("Location: admin_login.php?error=invalid_password");
            exit();
        }
    } else {
        // Student not found
        header("Location: admin_login.php?error=admin_not_found");
        exit();
    }
}

// Close the database connection
$conn->close();
?>
