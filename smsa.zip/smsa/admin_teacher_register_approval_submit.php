<?php

// Include your database connection file
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Retrieve form data
    $TeacherID = $_POST['TeacherID'];
    $registrationNumber = $_POST['RegistrationNumber'];

    // Update the student's registration details using mysqli_query
    $query = "UPDATE teachers SET RegistrationNumber = '$registrationNumber' WHERE TeacherID = $TeacherID";
    $result = mysqli_query($conn, $query);

    // Check if update was successful
    if ($result) {
      //  echo "Student registration approved successfully.";
        header("Location: admin_teacher_register_approval.php"); // Redirect to the student dashboard or home page

    } else {
        echo "Error approving student registration: " . mysqli_error($mysqli);
    }
}

// Close connection

?>
