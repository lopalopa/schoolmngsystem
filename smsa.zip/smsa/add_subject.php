
<?php
include "db.php";
include "header.php";
include "admin_sidebar.php"; 

?>

<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
    <div class="container-fluid"></div>
    <div class="container-fluid"></div>
      <div class="row" ></div>
      <div class="row" >
                    <div class="col-xl-4 col-lg-4 col-md-12 col-12" style="padding-top: 60px;padding-left: 60px;">
                    <div class="card" style="padding-top: 30px;">
            <h6 class="card-header" style="padding-top: 10px;"> NEW SUBJECT ENTRY FORM</h6>
            <div class="card-body">
            <form method="POST" action="add_subject_submit.php">
            <div class="form-group">
            <label for="classes">Select a Class:</label><br>
        <select id="classes" name="class_name" class="form-control form-control-lg"  required>
            <option value="">Select a Class</option>
            <?php

            include 'db.php';
            // Query to retrieve data from the database
            $query = "SELECT * FROM class";

            // Execute the query
            $result = $conn->query($query);

            // Check if the query was successful
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row["class_name"] . "'>" . $row["class_name"] . "</option>";
                }
            } else {
                echo "<option value=''>No classes found</option>";
            }

            // Close connection
            $conn->close();
            ?>
        </select>
 </div>
                    <div class="form-group">
                        <label for="inputUserName"> ADD SUBJECT</label>
                        <input class="form-control form-control-lg" name="sub_name"  id="sub_name" type="text" >
                    </div>
                    
                    <button type="submit" name="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                </form>

                </div>
                </div>
            </div>
            </div>
            </div>
            </section>
                <?php include("footer.php"); ?>
            </div>
